package HelloWorld;

import edu.princeton.cs.algs4.StdIn;

public class HelloGoodbye {
    public static void main(String[] args) {
        String name1 = StdIn.readString();
        String name2 = StdIn.readString();
        System.out.println("Hello " + name1 + " and " + name2 + ".");
        System.out.println("Goodbye " + name1 + " and " + name2 + ".");

    }
}